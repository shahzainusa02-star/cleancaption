CleanCaption v1.0 Beta — macOS

CleanCaption removes supported burned-in captions locally on your computer.

PRIVACY
Your selected video is processed locally. CleanCaption v1.0 Beta does not upload
your video to a CleanCaption server and does not require an API key.

SYSTEM REQUIREMENTS
- macOS
- Python 3
- FFmpeg
- Internet connection on first launch only to install Python packages

START
1. Extract the ZIP.
2. Right-click "Start CleanCaption.command".
3. Choose Open.
4. Keep the Terminal window open.
5. CleanCaption opens in your browser at http://127.0.0.1:8040
6. Choose a video and click Remove Captions.
7. Download the cleaned MP4.

BETA LIMITATION
v1.0 is optimized for centered white captions with a dark outline in the lower-middle
area of portrait videos. Other caption styles or positions may not be detected correctly.

UNINSTALL
Delete the CleanCaption folder. The Python environment is stored inside that folder.
